def alphabetical(words):
	return ','.join(sorted(words.split(',')))
